#include <iostream>
using namespace std;

int main() {
  int tall1;
  int tall2;

  cout << "Skriv et tall: ";
  cin >> tall1;
  cout << "Skriv et tall til: ";
  cin >> tall2;
  cout << "Summen blir: " << tall1 << " + " << tall2
    << " = " << tall1+tall2 << endl;
}
