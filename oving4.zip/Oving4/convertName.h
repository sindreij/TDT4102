
/**
 * testConvertName tester convert-name-funksjonen definert i convertName.cpp
 */
void testConvertName();