/* Beatle er en enum som består av de forskjellige
 * medlemmene i det kjente bandet beatles
 */
enum Beatle {JOHN, PAUL, GEORGE, RINGO};

/**
 * checkBeatlesEnumeration bruker Beatle på forskjellige
 * måter for å teste den. Den sjekker også funksjonen
 * isAlive deklarert i enumeration.cpp
 */
void checkBeatlesEnumeration();