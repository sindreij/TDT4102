void testTelefonNr();
