double hypotenuse(double side2, double side2);
int sum(int x, int y, int z);
void instructions();
double intToDouble(int heltall);
