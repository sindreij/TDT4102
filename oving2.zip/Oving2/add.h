int add(int a, int b);
double add(double a, double b);
void add(int& a, int& b, int& c, int& d);
